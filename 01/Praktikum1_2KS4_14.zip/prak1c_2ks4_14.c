#include <stdio.h>

void main() {
    int age, max, count;

    printf("Umur: ");
    scanf("%d", &age);
    int candle[age];

    for (int i = 0; i < age; i++) {
        printf("Lilin-%d: ", i+1);
        scanf("%d", &candle[i]);

        if (i==0 || candle[i]>max) {
            max = candle[i];
            count=1;
        } else if (candle[i]==max) {
            count++;
        }
    }
    
    printf("Jumlah lilin yang dapat dipadamkan %d", count);
    getch();
}